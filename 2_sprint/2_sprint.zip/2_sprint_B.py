# https://contest.yandex.ru/contest/22781/run-report/146162075/

# -- ПРИНЦИП РАБОТЫ ---
# По общему сценарию работы предполагается подача либо цифр либо команд для операций над цифрами.
# При получении команды, нужно обращаться к ранее полученным цифрам и делать вычисления, затем записывать результат вычислений.
# Для этого подойдет обычный стек.
# Логика работы такая, что если поступающая команда это цифра. то мы ее кладем на вершину стека и так со всеми цифрами.
# Если команда не цифра, то мы анализируем что это за арифметическое действие.
# Вынимаем сверху стека поочередно две цифры и совершаем над ними вычисление. Затем результат кладем снова на вершину стека.
# В конце концов возвращаем полученный результат вычислений


# -- ДОКАЗАТЕЛЬСТВА КОРРЕКТНОСТИ --
# Возможно алгоритм наивен, но он ровно укладывается в описываемый в условиях задачи процесс.
# Логика работы стека максимально и без существенных изменений соответствует условию задачи.


# -- ОПРЕДЕЛЕНИЕ СЛОЖНОСТИ АЛГОРИТМА --
# Сложность определяем как О(1), так как по сути при каждой введеной команде либо команда-цифра складывается,
# либо вычисляется арифметическое действие. Т.е. никаких цифлов или иных манипуляций зависящих от чего-либо не происходит.
# Пространственная сложность зависит от количества подаваемых команд, т.е. О(n)


class Queue:
    def __str__(self):
        """класс стек"""

    def __init__(self):
        self.queue = list()  # элементы очереди --- ОБЫЧНЫЙ СПИСОК
        self.first = None
        self.second = None


    def push(self, x):
        """добавить число x в стек"""
        #print(f'push {x} {type(x)}')
        self.queue.append(x)

    def pop(self):
        """взять число с вершины стека"""
        #print('pop')
        return self.queue.pop()

    def logic(self, command):
        """логика работы с арифметикой"""
        #print('logic')
        self.second = self.pop()
        self.first = self.pop()

        if command == '+':
            self.push(self.first + self.second)
        elif command == '-':
            self.push(self.first - self.second)
        elif command == '*':
            self.push(self.first * self.second)
        elif command == '/':
            self.push(self.first // self.second)

    def digit_check(self, command):
        """проверка, является ли строка числом, даже отрицательным"""
        try:
            int(command)
            return True
        except ValueError:
            return False



if __name__ == '__main__':

    queue = Queue()

    commands_list = input().strip().split()  # читаем символы нотации на вводе
    #print(commands_list)

    for command in commands_list:
        if queue.digit_check(command):
            #print('это цифра')
            queue.push(int(command))
        else:
            queue.logic(command)

    print(queue.pop())